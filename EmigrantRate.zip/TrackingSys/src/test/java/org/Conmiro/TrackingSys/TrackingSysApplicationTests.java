package org.Conmiro.TrackingSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackingSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
